import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ART RESEARCH STUDIO — Personal Art Research",
  description: "A private bilingual studio for art, design, artists, papers and material research.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
