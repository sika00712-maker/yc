'use client';

import { useState } from "react";
import {
  ArrowUpRight, Bookmark, BookOpen, Boxes, CalendarDays, ChevronRight,
  CircleUserRound, Compass, Feather, FlaskConical, Globe2, Library,
  Search, Sparkles, StickyNote
} from "lucide-react";

const copy = {
  en: {
    eyebrow: "A PRIVATE SPACE FOR CURIOUS MINDS",
    title: "Research is a way of seeing.",
    intro: "A growing collection of ideas, artists, materials and critical writing — gathered to support a more thoughtful creative practice.",
    today: "TODAY IN THE STUDIO",
    date: "YOUR DAILY RESEARCH EDITION",
    artists: "Artist to explore",
    papers: "Papers to read",
    notes: "Reading notes",
    artistTitle: "The artist file",
    paperTitle: "The paper desk",
    noteTitle: "A note before you read",
    artistDesc: "A focused introduction to an artist’s ideas, visual language, materials and working methods.",
    paperDesc: "A carefully selected academic text, with a clear route into its argument, methods and contribution.",
    noteDesc: "Use the prompts to read actively. Your notes will eventually become part of your private research archive.",
    explore: "Explore the archive",
    open: "Open research",
    prompt: "Reading prompts",
    p1: "What question is this research trying to answer?",
    p2: "Which material, process or visual strategy matters most?",
    p3: "What do I agree or disagree with — and why?",
    p4: "What new experiment or connection does this suggest?",
    sections: "RESEARCH AREAS",
    areas: ["Papers", "Artists", "Materials", "Objects & Space", "Archive"],
    footer: "A personal research practice, built one question at a time.",
    private: "PRIVATE STUDIO",
    search: "Search artists, papers, materials…",
    nav: ["Overview", "Papers", "Artists", "Materials", "Objects", "Archive"],
  },
  zh: {
    eyebrow: "为好奇心保留一处私人空间",
    title: "研究，是一种观看世界的方式。",
    intro: "持续生长的艺术家、材料、学术论文与批判性写作资料库，为更深入的创作实践提供支持。",
    today: "今日工作室",
    date: "每日研究专刊",
    artists: "今日艺术家",
    papers: "今日论文",
    notes: "阅读笔记",
    artistTitle: "艺术家档案",
    paperTitle: "论文阅读台",
    noteTitle: "阅读前，先问自己",
    artistDesc: "从艺术家的创作观念、视觉语言、材料选择与工作方法出发，建立有深度的认识。",
    paperDesc: "精选学术文本，梳理研究问题、论证路径、方法与学术贡献。",
    noteDesc: "用下面的问题进行主动阅读。你的笔记最终会沉淀为私人研究档案。",
    explore: "探索研究档案",
    open: "进入研究",
    prompt: "阅读提示",
    p1: "这项研究试图回答什么问题？",
    p2: "其中最重要的材料、工艺或视觉策略是什么？",
    p3: "我认同或质疑哪些观点？为什么？",
    p4: "它能引出什么新的实验或知识关联？",
    sections: "研究领域",
    areas: ["学术论文", "艺术家", "材料实验", "器物与空间", "个人档案"],
    footer: "一次提出一个问题，慢慢建立自己的研究实践。",
    private: "私人工作室",
    search: "搜索艺术家、论文、材料……",
    nav: ["总览", "论文", "艺术家", "材料", "器物", "档案"],
  }
};

const areaIcons = [BookOpen, Feather, FlaskConical, Boxes, Library];

export default function Home() {
  const [lang, setLang] = useState<"en" | "zh">("zh");
  const t = copy[lang];

  return (
    <main className="shell">
      <aside className="sidebar">
        <a className="brand" href="#">
          <span className="brand-mark">AR<span>·</span></span>
          <span className="brand-name">ART RESEARCH<br/>STUDIO</span>
        </a>
        <div className="side-label">{lang === "zh" ? "工作室" : "STUDIO"}</div>
        <nav className="side-nav">
          {t.nav.map((item, i) => (
            <a key={item} className={i === 0 ? "nav-item active" : "nav-item"} href={i === 0 ? "#" : "#research-areas"}>
              {i === 0 ? <Compass size={17}/> : i === 1 ? <BookOpen size={17}/> : i === 2 ? <Feather size={17}/> : i === 3 ? <FlaskConical size={17}/> : i === 4 ? <Boxes size={17}/> : <Library size={17}/>}
              <span>{item}</span>{i === 0 && <span className="nav-dot"/>}
            </a>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="private-tag"><span className="status-dot"/>{t.private}</div>
          <div className="profile"><div className="avatar">A</div><div><strong>My Research Space</strong><small>Personal account</small></div><CircleUserRound size={17}/></div>
        </div>
      </aside>

      <section className="main-area">
        <header className="topbar">
          <div className="breadcrumb">STUDIO <span>/</span> {lang === "zh" ? "总览" : "OVERVIEW"}</div>
          <div className="top-actions">
            <label className="search"><Search size={16}/><input placeholder={t.search}/><kbd>⌘ K</kbd></label>
            <button className="lang-switch" onClick={() => setLang(lang === "zh" ? "en" : "zh")} aria-label="Switch language"><Globe2 size={16}/>{lang === "zh" ? "中 / EN" : "EN / 中"}</button>
            <button className="avatar small" aria-label="Profile">A</button>
          </div>
        </header>

        <div className="content">
          <section className="hero">
            <div className="hero-copy">
              <div className="eyebrow"><span className="eyebrow-line"/>{t.eyebrow}</div>
              <h1>{t.title}</h1>
              <p>{t.intro}</p>
              <a href="#today" className="text-link">{t.explore}<ArrowUpRight size={16}/></a>
            </div>
            <div className="hero-art" aria-label="Abstract editorial artwork">
              <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
              <div className="art-shape shape-one"/><div className="art-shape shape-two"/>
              <div className="art-shape shape-three"/><div className="art-caption">FORM / MATTER / THOUGHT<br/>FIELD NOTES Nº 001</div>
            </div>
            <div className="hero-index">01 — 05<br/>RESEARCH JOURNAL</div>
          </section>

          <section id="today" className="today-section">
            <div className="section-head">
              <div><div className="eyebrow muted">{t.today}</div><h2>{t.date}</h2></div>
              <div className="date-stamp"><CalendarDays size={15}/> DAILY EDITION <span>·</span> 08:00</div>
            </div>
            <div className="feature-grid">
              <article className="feature-card artist-card">
                <div className="card-top"><span className="card-kicker">01 / ARTIST STUDY</span><Bookmark size={17}/></div>
                <div className="artist-visual"><div className="visual-ring"/><div className="visual-block"/><div className="visual-disc"/></div>
                <div className="card-content"><div className="card-type">{t.artists}</div><h3>{t.artistTitle}</h3><p>{t.artistDesc}</p><a href="#research-areas">{t.open}<ArrowUpRight size={15}/></a></div>
              </article>
              <article className="feature-card paper-card">
                <div className="card-top"><span className="card-kicker">02 / ACADEMIC READING</span><BookOpen size={17}/></div>
                <div className="paper-visual"><div className="paper-sheet"><span>JOURNAL / RESEARCH</span><i/><i/><i/><b>FORM<br/>& MATTER</b><i/></div></div>
                <div className="card-content"><div className="card-type">{t.papers}</div><h3>{t.paperTitle}</h3><p>{t.paperDesc}</p><a href="#research-areas">{t.open}<ArrowUpRight size={15}/></a></div>
              </article>
              <article className="feature-card notes-card">
                <div className="card-top"><span className="card-kicker">03 / ACTIVE READING</span><StickyNote size={17}/></div>
                <div className="notes-visual"><div className="note-lines"><span/><span/><span/><span/></div><div className="note-stamp">READ<br/>THINK<br/>CONNECT</div></div>
                <div className="card-content"><div className="card-type">{t.notes}</div><h3>{t.noteTitle}</h3><p>{t.noteDesc}</p><a href="#reading-prompts">{t.prompt}<ArrowUpRight size={15}/></a></div>
              </article>
            </div>
          </section>

          <section id="reading-prompts" className="prompts-section">
            <div className="prompt-heading"><div><div className="eyebrow muted">A SMALL READING RITUAL</div><h2>{t.prompt}</h2></div><Sparkles size={19}/></div>
            <div className="prompt-list">
              {[t.p1,t.p2,t.p3,t.p4].map((p,i)=><div className="prompt-row" key={p}><span>0{i+1}</span><p>{p}</p><ChevronRight size={16}/></div>)}
            </div>
            <div className="prompt-foot">NOTE TO SELF — {lang === "zh" ? "先观察，再判断；先理解，再连接。" : "OBSERVE FIRST. INTERPRET SECOND. CONNECT ALWAYS."}</div>
          </section>

          <section id="research-areas" className="areas-section">
            <div className="section-head"><div><div className="eyebrow muted">{t.sections}</div><h2>Explore the fields.</h2></div><span className="area-count">05 COLLECTIONS</span></div>
            <div className="area-grid">
              {t.areas.map((area,i)=>{const Icon=areaIcons[i];return <a className="area-item" href="#" key={area}><span className="area-icon"><Icon size={19}/></span><span>{area}</span><ArrowUpRight size={15}/></a>})}
            </div>
          </section>
          <footer><span>ART RESEARCH STUDIO © 2026</span><span>{t.footer}</span><span>BUILT FOR INQUIRY.</span></footer>
        </div>
      </section>
    </main>
  );
}
