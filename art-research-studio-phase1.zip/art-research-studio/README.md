# ART RESEARCH STUDIO

A private, bilingual art research platform starter.

## Phase 1 prototype
- Editorial homepage and navigation
- Chinese / English language toggle
- Daily research sections for artist study, academic reading and active reading notes
- Reading prompts
- Research area entry points
- Responsive desktop and mobile layout

## Run locally
Requires Node.js 20+.

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Current status and boundaries
This is the Phase 1 front-end prototype. It uses illustrative visual placeholders and editorial copy; it does not yet fetch live papers, store notes, authenticate users, or run scheduled daily updates.

## Planned next phases
1. Connect a private GitHub repository and deploy to a hosting provider under the owner's account.
2. Add Supabase authentication, PostgreSQL tables and private storage.
3. Build real paper/artist records, source provenance, reading-note editor and archive.
4. Add the daily research pipeline and scheduled publishing. The recurring 08:00 target is approximate and must be configured in the owner's timezone.

## Ownership
Keep the GitHub repository, domain registrar, hosting and database accounts in the site owner's name. Never commit API keys. Use environment variables for secrets.
